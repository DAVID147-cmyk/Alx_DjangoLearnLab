# Managing Permissions and Groups in Django

## Overview
This app demonstrates role-based access control (RBAC) in Django using groups and permissions.

## Custom Permissions
- can_view
- can_create
- can_edit
- can_delete

## Groups
- Viewers → can view posts only
- Editors → can view, create, edit
- Admins → full permissions

## How to Test
1. Run `python manage.py runserver`
2. Log in to `/admin` as superuser.
3. Create users and assign them to groups.
4. Test creating, editing, or viewing posts.
